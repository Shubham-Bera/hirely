const features = [
    "Smart Job Search Filters",
    "Resume Builder & Templates",
    "One-Click Quick Apply",
    "Instant Interview Notifications",
    "Application Status Tracking",
    "Verified Company Profiles",
    "AI-Powered Job Matching",
    "Schedule Interviews Seamlessly"
  ];

  const featureText = document.getElementById("feature-text");
  let index = 0;

  function showNextFeature() {
    featureText.style.opacity = 0;

    setTimeout(() => {
      featureText.textContent = features[index];
      featureText.style.opacity = 1;
      index = (index + 1) % features.length;
    }, 500);
  }

  // Initial display
  showNextFeature();
  setInterval(showNextFeature, 3000); 

