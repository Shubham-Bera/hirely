import { jobList } from "../models/jobPortal.model.js";
export default class JobPortalController{

    static renderHomePage(req,res){
        res.render("home");
    }

    static renderJobs(req,res){
        res.render("jobs",{jobList});
    }

    static renderJobDesc(req,res){     
        const jobId = parseInt(req.params.id);
        const job = jobList.find(j => j.id === jobId);

        if (job) {
            res.render('jobDescription', { job });
        } else {
            res.status(404).send("Job not found");
        }
    }
}