import app from "./index.js"

const port = 3000;
app.listen(port,()=>{
    console.log(`Server start at port ${port}`);
})