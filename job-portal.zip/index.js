import express from "express";
import path from "path";
import expressEjsLayouts from "express-ejs-layouts";
import JobPortalController from "./src/controllers/jobPortal.controller.js";

const app = express();

app.use(express.static(path.resolve("src","public")));
app.set("view engine","ejs");
app.set("views",path.resolve("src","views"));
app.use(expressEjsLayouts);

app.get("/",JobPortalController.renderHomePage);
app.get("/jobs",JobPortalController.renderJobs);
app.get("/jobs/:id", JobPortalController.renderJobDesc);
export default app;